function Component()
{
    // constructor
}

Component.prototype.createOperations = function()
{
    // Call the base implementation to actually install the files
    component.createOperations();

    // Print a message to the command line
    console.log("Installing package...");

    // Add your SQL commands here
    if (installer.value("os") === "win") {
        var programFilesPath = installer.environmentVariable("ProgramFiles(x86)");
        if (programFilesPath === "") {
            programFilesPath = installer.environmentVariable("ProgramFiles");
        }
        // Check the connection to the SQL service
        component.addOperation("Execute", "{0,3010}", "@TargetDir@\\your_sql_script.bat",
                               programFilesPath + "\\MySQL\\MySQL Server 5.7\\bin\\",
                               "SELECT 1",
                               installer.value("USERNAME"),
                               installer.value("USERPASSWORD"));
        // If the previous operation was successful, the connection to the SQL service is working
        console.log("Connected to the SQL service");
    }
}
